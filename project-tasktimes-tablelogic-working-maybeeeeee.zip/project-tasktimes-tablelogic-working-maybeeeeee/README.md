# Project Task - Times Table - Logic working maybeeeeee

A Pen created on CodePen.

Original URL: [https://codepen.io/Rich-Naish/pen/ZYzmdPO](https://codepen.io/Rich-Naish/pen/ZYzmdPO).

